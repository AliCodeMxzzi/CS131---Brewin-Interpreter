class EnvironmentManager:
    def __init__(self):
        self.scopes = [{}]

    def get(self, symbol):
        for scope in reversed(self.scopes):
            if symbol in scope:
                return scope[symbol]
        return None

    def set(self, symbol, value):
        for scope in reversed(self.scopes):
            if symbol in scope:
                scope[symbol] = value
                return True
        return False

    def create(self, symbol, start_val):
        if symbol not in self.scopes[-1]:  
            self.scopes[-1][symbol] = start_val
            return True
        return False

    def push_scope(self):
        self.scopes.append({})

    def pop_scope(self):
        self.scopes.pop()