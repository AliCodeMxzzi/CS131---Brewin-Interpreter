from env_v2 import EnvironmentManager
from type_valuev2 import Type, Value, create_value, get_printable
from intbase import InterpreterBase, ErrorType
from brewparse import parse_program
import copy

class Interpreter(InterpreterBase):
    BIN_OPS = {"+", "-", "*", "/", "&&", "||", "==", "!=", ">", ">=", "<", "<="}
    UNARY_OPS = {"neg", "!"}
    NIL = create_value(InterpreterBase.NIL_DEF)
    TRUE = create_value(InterpreterBase.TRUE_DEF)
    FALSE = create_value(InterpreterBase.FALSE_DEF)

    def __init__(self, console_output=True, inp=None, trace_output=False):
        super().__init__(console_output, inp)
        self.trace_output = trace_output
        self.__setup_ops()

    def run(self, program):
        ast = parse_program(program)
        self.__set_up_function_table(ast)
        main_func = self.__get_func_by_name("main")
        self.env = EnvironmentManager()
        self.__run_statements(main_func.get("statements"))

    def __set_up_function_table(self, ast):
        self.func_name_to_ast = {}
        for func_def in ast.get("functions"):
            if (func_def.get("name"), len(func_def.get("args"))) in self.func_name_to_ast:
                super().error(ErrorType.NAME_ERROR, "Function with same name and number of arguments already declared")
            self.func_name_to_ast[(func_def.get("name"), len(func_def.get("args")))] = func_def

    def __get_func_by_name(self, name, arg_count=0):
        if (name, arg_count) not in self.func_name_to_ast:
            super().error(ErrorType.NAME_ERROR, f"Function {name} was not found")
        return self.func_name_to_ast[(name, arg_count)]

    def __run_statements(self, statements):
        self.env.push_scope()
        for statement in statements:
            if self.trace_output:
                print(statement)
            returned = False
            if statement.elem_type == InterpreterBase.FCALL_NODE:
                self.__call_func(statement)
            elif statement.elem_type == "=":
                self.__assign(statement)
            elif statement.elem_type == InterpreterBase.VAR_DEF_NODE:
                self.__var_def(statement)
            elif statement.elem_type == InterpreterBase.IF_NODE:
                returned, return_val = self.__run_if_statement(statement)
            elif statement.elem_type == InterpreterBase.FOR_NODE:
                returned, return_val = self.__run_for_statement(statement)
            elif statement.elem_type == InterpreterBase.RETURN_NODE:
                returned, return_val = self.__run_return(statement)
            if returned == True:
                self.env.pop_scope()
                return (returned, return_val)
        self.env.pop_scope()
        return (False, Interpreter.NIL)

    def __run_if_statement(self, if_ast):
        condition = self.__eval_expr(if_ast.get("condition"))
        if condition.type() != Type.BOOL:
            super().error(ErrorType.TYPE_ERROR, "Condition must be a boolean")

        if condition.value():
            returned, return_val = self.__run_statements(if_ast.get("statements"))
            return (returned, return_val)
        elif if_ast.get("else_statements"):
            returned, return_val = self.__run_statements(if_ast.get("else_statements"))
            return (returned, return_val)
        return (False, Interpreter.NIL)

    def __run_for_statement(self, for_ast):
        self.__assign(for_ast.get("init"))
        condition = self.__eval_expr(for_ast.get("condition"))
        if condition.type() != Type.BOOL:
            super().error(ErrorType.TYPE_ERROR, "Condition must be a boolean")
 
        while self.__eval_expr(for_ast.get("condition")).value():
            returned, return_val = self.__run_statements(for_ast.get("statements"))
            if (returned == True):
                return returned, return_val
            self.__assign(for_ast.get("update"))
        return (False, Interpreter.NIL)

    def __run_return(self, return_ast):
        if return_ast.get("expression"):
            saved_value = copy.deepcopy(self.__eval_expr(return_ast.get("expression")))
            return (True, saved_value)
        return (True, Interpreter.NIL)

    def __call_func(self, call_node):
        func_name = call_node.get("name")
        if func_name == "print":
            return self.__call_print(call_node)
        if func_name == "inputi":
            return self.__call_input(call_node)
        if func_name == "inputs":
            return self.__call_input(call_node)

        func_def = self.__get_func_by_name(func_name, len(call_node.get("args")))
        func_args = func_def.get("args")
        if len(func_args) != len(call_node.get("args")):
            super().error(ErrorType.NAME_ERROR, "Function call with wrong number of arguments")
        self.env.push_scope()
        for arg_node, arg_value in zip(func_args, call_node.get("args")):
            saved_value = copy.deepcopy(self.__eval_expr(arg_value))
            self.env.create(arg_node.get("name"), saved_value)
        returned, return_val = self.__run_statements(func_def.get("statements"))
        self.env.pop_scope()
        return return_val if returned == True else Interpreter.NIL

    def __call_print(self, call_ast):
        output = ""
        for arg in call_ast.get("args"):
            result = self.__eval_expr(arg)  # result is a Value object
            output = output + get_printable(result)
        super().output(output)
        return Interpreter.NIL

    def __call_input(self, call_ast):
        args = call_ast.get("args")
        if args is not None and len(args) == 1:
            result = self.__eval_expr(args[0])
            super().output(get_printable(result))
        elif args is not None and len(args) > 1:
            super().error(
                ErrorType.NAME_ERROR, "No input() function that takes > 1 parameter"
            )
        inp = super().get_input()
        if call_ast.get("name") == "inputi":
            return Value(Type.INT, int(inp))
        if call_ast.get("name") == "inputs":
            return Value(Type.STRING, str(inp))

    def __assign(self, assign_ast):
        var_name = assign_ast.get("name")
        value_obj = self.__eval_expr(assign_ast.get("expression"))
        if not self.env.set(var_name, value_obj):
            super().error(ErrorType.NAME_ERROR, f"Undefined variable {var_name} in assignment")

    def __var_def(self, var_ast):
        var_name = var_ast.get("name")
        if not self.env.create(var_name, Value(Type.INT, 0)):
            super().error(ErrorType.NAME_ERROR, f"Duplicate definition for variable {var_name}")

    def __eval_expr(self, expr_ast):
        if expr_ast.elem_type == InterpreterBase.INT_NODE:
            return Value(Type.INT, expr_ast.get("val"))
        if expr_ast.elem_type == InterpreterBase.STRING_NODE:
            return Value(Type.STRING, expr_ast.get("val"))
        if expr_ast.elem_type == InterpreterBase.BOOL_NODE:
            return Value(Type.BOOL, expr_ast.get("val"))
        if expr_ast.elem_type == InterpreterBase.NIL_NODE:
            return Interpreter.NIL
        if expr_ast.elem_type == InterpreterBase.VAR_NODE:
            var_name = expr_ast.get("name")
            val = self.env.get(var_name)
            if val is None:
                super().error(ErrorType.NAME_ERROR, f"Variable {var_name} not found")
            return val
        if expr_ast.elem_type == InterpreterBase.FCALL_NODE:
            return self.__call_func(expr_ast)
        if expr_ast.elem_type in Interpreter.BIN_OPS:
            return self.__eval_op(expr_ast)
        if expr_ast.elem_type in Interpreter.UNARY_OPS:
            return self.__eval_unary(expr_ast)

    def __eval_op(self, arith_ast):
        left_value_obj = self.__eval_expr(arith_ast.get("op1"))
        right_value_obj = self.__eval_expr(arith_ast.get("op2"))
        op = arith_ast.elem_type

        if left_value_obj.type() == Type.NIL and right_value_obj.type() == Type.NIL:
            if op == "==":
                return self.op_to_lambda[Type.NIL]["=="](left_value_obj, right_value_obj)
            elif op == "!=":
                return self.op_to_lambda[Type.NIL]["!="](left_value_obj, right_value_obj)
        
        if op in {"==", "!="}:
            if left_value_obj.type() != right_value_obj.type():
                if op == "==":
                    return Interpreter.FALSE
                else:
                    return Interpreter.TRUE
        elif left_value_obj.type() != right_value_obj.type():
            super().error(
                ErrorType.TYPE_ERROR,
                f"Incompatible types for {op} operation",
            )
        if op not in self.op_to_lambda[left_value_obj.type()]:
            super().error(
                ErrorType.TYPE_ERROR,
                f"Incompatible operator {op} for type {left_value_obj.type()}",
            )
        f = self.op_to_lambda[left_value_obj.type()][op]
        return f(left_value_obj, right_value_obj)

    def __eval_unary(self, unary_ast):
        op1 = self.__eval_expr(unary_ast.get("op1"))
        if unary_ast.elem_type == "neg":
            if op1.type() != Type.INT:
                super().error(ErrorType.TYPE_ERROR, "Unary negation is only allowed on integers")
            return self.op_to_lambda[Type.INT]["neg"](op1)
        elif unary_ast.elem_type == "!":
            if op1.type() != Type.BOOL:
                super().error(ErrorType.TYPE_ERROR, "Logical NOT is only allowed on booleans")
            return self.op_to_lambda[Type.BOOL]["!"](op1)

    def __setup_ops(self):
        self.op_to_lambda = {}
        # set up operations on integers
        self.op_to_lambda[Type.INT] = {}
        self.op_to_lambda[Type.INT]["+"] = lambda x, y: Value(
            x.type(), x.value() + y.value()
        )
        self.op_to_lambda[Type.INT]["-"] = lambda x, y: Value(
            x.type(), x.value() - y.value()
        )
        self.op_to_lambda[Type.INT]["*"] = lambda x, y: Value(
            x.type(), x.value() * y.value()
        )
        self.op_to_lambda[Type.INT]["/"] = lambda x, y: Value(
            x.type(), x.value() // y.value()
        )
        self.op_to_lambda[Type.INT]["=="] = lambda x, y: Value(
            Type.BOOL, x.value() == y.value()
        )
        self.op_to_lambda[Type.INT]["!="] = lambda x, y: Value(
            Type.BOOL, x.value() != y.value()
        )
        self.op_to_lambda[Type.INT][">"] = lambda x, y: Value(
            Type.BOOL, x.value() > y.value()
        )
        self.op_to_lambda[Type.INT][">="] = lambda x, y: Value(
            Type.BOOL, x.value() >= y.value()
        )
        self.op_to_lambda[Type.INT]["<"] = lambda x, y: Value(
            Type.BOOL, x.value() < y.value()
        )
        self.op_to_lambda[Type.INT]["<="] = lambda x, y: Value(
            Type.BOOL, x.value() <= y.value()
        )
        self.op_to_lambda[Type.INT]["neg"] = lambda x: Value(
            x.type(), x.value() * -1
        )

        self.op_to_lambda[Type.BOOL] = {}
        self.op_to_lambda[Type.BOOL]["&&"] = lambda x, y: Value(
            Type.BOOL, x.value() & y.value()
        )
        self.op_to_lambda[Type.BOOL]["||"] = lambda x, y: Value(
            Type.BOOL, x.value() | y.value()
        )
        self.op_to_lambda[Type.BOOL]["=="] = lambda x, y: Value(
            Type.BOOL, x.value() == y.value()
        )
        self.op_to_lambda[Type.BOOL]["!="] = lambda x, y: Value(
            Type.BOOL, x.value() != y.value()
        )
        self.op_to_lambda[Type.BOOL]["!"] = lambda x: Value(
            Type.BOOL, not x.value()
        )

        self.op_to_lambda[Type.STRING] = {}
        self.op_to_lambda[Type.STRING]["+"] = lambda x, y: Value(
            x.type(), x.value() + y.value()
        )
        self.op_to_lambda[Type.STRING]["=="] = lambda x, y: Value(
            Type.BOOL, x.value() == y.value()
        )
        self.op_to_lambda[Type.STRING]["!="] = lambda x, y: Value(
            Type.BOOL, x.value() != y.value()
        )

        self.op_to_lambda[Type.NIL] = {}
        self.op_to_lambda[Type.NIL]["=="] = lambda x, y: Value(
            Type.BOOL, x.value() == y.value()
        )
        self.op_to_lambda[Type.NIL]["!="] = lambda x, y: Value(
            Type.BOOL, x.value() != y.value()
        )
        # add other operators here later for int, string, bool, etc