from intbase import InterpreterBase, ErrorType
from brewparse import parse_program

class Interpreter(InterpreterBase):
    def __init__(self, console_output=True, inp=None, trace_output=False):
        super().__init__(console_output, inp)

        self.funcs = {} # {(name,n_args):element,}
        self.vars = [] # [({name:(type,val),},bool),]
        self.structs = {} # {name: {fields,},}
        self.bops = {'+', '-', '*', '/', '==', '!=', '>', '>=', '<', '<=', '||', '&&'}

    def run(self, program):
        ast = parse_program(program)
        self.ast = ast

        for struct in ast.get('structs'):
            self.structs[struct.get('name')] = {field.get('name'): field.get('var_type') for field in struct.get('fields')}

        for func in ast.get('functions'):
            if func.get('return_type') == '' or (func.get('return_type') not in ['bool', 'int', 'string', 'void'] and func.get('return_type') not in self.structs):
                super().error(ErrorType.TYPE_ERROR, '')
            for arg in func.get('args'):
                if arg.get('var_type') == '' or (arg.get('var_type') not in ['bool', 'int', 'string'] and arg.get('var_type') not in self.structs):
                    super().error(ErrorType.TYPE_ERROR, '')
            self.funcs[(func.get('name'),len(func.get('args')))] = func

        main_key = None

        for k in self.funcs:
            if k[0] == 'main':
                main_key = k
                break

        if main_key is None:
            super().error(ErrorType.NAME_ERROR, '')

        self.run_fcall(self.funcs[main_key])

    def run_vardef(self, statement):
        name = statement.get('name')
        var_type = statement.get('var_type')

        if var_type not in ['bool', 'int', 'string'] and var_type not in self.structs:
            super().error(ErrorType.TYPE_ERROR, '')

        if name in self.vars[-1][0]:
            super().error(ErrorType.NAME_ERROR, '')

        def_val = self.default_value(var_type)
        self.vars[-1][0][name] = (var_type, def_val)

    def run_assign(self, statement):
        name = statement.get('name')

        if '.' in name:
            field_path = name.split('.')
            root_name = field_path[0]

            # Find the struct in scope
            for scope_vars, is_func in self.vars[::-1]:
                if root_name in scope_vars:
                    struct_type, struct_value = scope_vars[root_name]

                    # Validate struct and non-nil reference
                    if struct_type not in self.structs:
                        super().error(ErrorType.TYPE_ERROR, f"{root_name} is not a struct")
                    if struct_value is None:
                        super().error(ErrorType.FAULT_ERROR, f"Accessing field of nil struct {root_name}")

                    # Traverse fields
                    current_struct = struct_value
                    current_type = struct_type
                    for field in field_path[1:-1]:
                        if field not in self.structs[current_type]:
                            super().error(ErrorType.NAME_ERROR, f"{field} does not exist in {current_type}")
                        current_type = self.structs[current_type][field]
                        current_struct = current_struct.get(field)
                        if current_type in self.structs and current_struct is None:
                            super().error(ErrorType.FAULT_ERROR, f"Accessing field of nil struct {field}")

                    # Final field validation and assignment
                    final_field = field_path[-1]
                    if final_field not in self.structs[current_type]:
                        super().error(ErrorType.NAME_ERROR, f"{final_field} is not a valid field in {current_type}")

                    val = self.run_expr(statement.get('expression'))
                    field_type = self.structs[current_type][final_field]
                    if not self.type_compatible(field_type, val):
                        super().error(ErrorType.TYPE_ERROR, f"Incompatible type for field {final_field}")
                    current_struct[final_field] = val
                    return

        for scope_vars, is_func in self.vars[::-1]:
            if name in scope_vars:
                var_type, _ = scope_vars[name]
                val = self.run_expr(statement.get('expression'))

                if not self.type_compatible(var_type, val):
                    super().error(ErrorType.TYPE_ERROR, '')

                scope_vars[name] = (var_type, val)
                return

            if is_func: break

        super().error(ErrorType.NAME_ERROR, '')

    def run_fcall(self, statement):
        fcall_name, args = statement.get('name'), statement.get('args')

        if fcall_name == 'inputi' or fcall_name == 'inputs':
            if len(args) > 1:
                super().error(ErrorType.NAME_ERROR, '')

            if args:
                super().output(str(self.run_expr(args[0])))

            res = super().get_input()

            return int(res) if fcall_name == 'inputi' else res

        if fcall_name == 'print':
            out = ''

            for arg in args:
                c_out = self.run_expr(arg)
                if type(c_out) == bool:
                    out += str(c_out).lower()
                elif c_out is None:
                    out += "nil"
                else:
                    out += str(c_out)

            super().output(out)

            return None
        
        if (fcall_name, len(args)) not in self.funcs:
            super().error(ErrorType.NAME_ERROR, '')

        func_def = self.funcs[(fcall_name, len(args))]

        template_args = [a.get('name') for a in func_def.get('args')]
        type_args = [a.get('var_type') for a in func_def.get('args')]
        passed_args = [self.run_expr(a) for a in args]

        
        for arg_type, arg_val in zip(type_args, passed_args):
            if arg_type == 'bool' and isinstance(arg_val, int):
                arg_val = self.coerce_to_bool(arg_val)
            if not self.type_compatible(arg_type, arg_val):
                super().error(ErrorType.TYPE_ERROR, '')

        self.vars.append(({k: (type_args[i], v) for i, (k, v) in enumerate(zip(template_args, passed_args))}, True))
        res, _ = self.run_statements(func_def.get('statements'), func_def.get('return_type'))
        self.vars.pop()

        return res

    def run_if(self, statement):
        cond = self.run_expr(statement.get('condition'))

        if type(cond) != bool and type(cond) != int:
            super().error(ErrorType.TYPE_ERROR, '')
        cond = self.coerce_to_bool(cond)

        self.vars.append(({}, False))

        res, ret = None, False

        if cond:
            res, ret = self.run_statements(statement.get('statements'))
        elif statement.get('else_statements'):
            res, ret = self.run_statements(statement.get('else_statements'))

        self.vars.pop()

        return res, ret

    def run_for(self, statement):
        res, ret = None, False

        self.run_assign(statement.get('init'))

        while True:
            cond = self.run_expr(statement.get('condition'))

            if type(cond) != bool and type(cond) != int:
                super().error(ErrorType.TYPE_ERROR, '')
            cond = self.coerce_to_bool(cond)

            if ret or not cond: break

            self.vars.append(({}, False))
            res, ret = self.run_statements(statement.get('statements'))
            self.vars.pop()

            self.run_assign(statement.get('update'))

        return res, ret

    def run_return(self, statement, return_type):
        expr = statement.get('expression')
        if expr is None:
            if return_type == 'void':
                return None
            return self.default_value(return_type)
        
        return_value = self.run_expr(expr)

        # Validate the return value's type
        if return_type == 'bool' and isinstance(return_value, int) and not isinstance(return_value, bool):
            return bool(return_value)  # Coerce int to bool
        if return_type == 'bool' and isinstance(return_value, bool):
            return return_value
        if return_type == 'int' and isinstance(return_value, int) and not isinstance(return_value, bool):
            return return_value
        if return_type == 'string' and isinstance(return_value, str):
            return return_value
        if return_type in self.structs:
            if return_value is None:  # Allow nil for struct types
                return None
            if isinstance(return_value, dict):  # Ensure struct compatibility
                return return_value

        # If void function, but a value is returned
        if return_type == 'void':
            super().error(ErrorType.TYPE_ERROR, "Void function cannot return a value")

        # Invalid return type
        super().error(ErrorType.TYPE_ERROR, f"Incompatible return type: expected {return_type}, got {type(return_value).__name__}")
        
        return None

    def run_statements(self, statements, return_type=None):
        res, ret = self.default_value(return_type), False

        for statement in statements:
            kind = statement.elem_type

            if kind == 'vardef':
                self.run_vardef(statement)
            elif kind == '=':
                self.run_assign(statement)
            elif kind == 'fcall':
                self.run_fcall(statement)
            elif kind == 'if':
                res, ret = self.run_if(statement)
                if ret: break
            elif kind == 'for':
                res, ret = self.run_for(statement)
                if ret: break
            elif kind == 'return':
                res = self.run_return(statement, return_type)
                ret = True
                break

        return res, ret

    def run_expr(self, expr):
        kind = expr.elem_type

        if kind == 'int' or kind == 'string' or kind == 'bool':
            return expr.get('val')

        elif kind == 'var':
            var_name = expr.get('name')

            if '.' in var_name:
                field_path = var_name.split('.')
                root_name = field_path[0]

                for scope_vars, is_func in self.vars[::-1]:
                    if root_name in scope_vars:
                        struct_type, struct_value = scope_vars[root_name]
                        if struct_value is None:
                            super().error(ErrorType.FAULT_ERROR, f"Accessing field of nil struct {root_name}")
                        if struct_type not in self.structs:
                            super().error(ErrorType.TYPE_ERROR, f"{root_name} is not a struct")

                        # Traverse fields
                        current_value = struct_value
                        current_type = struct_type
                        for field in field_path[1:]:
                            if field not in self.structs[current_type]:
                                super().error(ErrorType.NAME_ERROR, f"{field} does not exist in {current_type}")
                            current_type = self.structs[current_type][field]
                            current_value = current_value.get(field)
                            if current_value is None and current_type in self.structs:
                                super().error(ErrorType.FAULT_ERROR, f"Accessing field of nil struct {field}")
                        return current_value
                    
                    if is_func: break

            for scope_vars, is_func in self.vars[::-1]:
                if var_name in scope_vars:
                    return scope_vars[var_name][1]

                if is_func: break

            super().error(ErrorType.NAME_ERROR, '')

        elif kind == 'fcall':
            return self.run_fcall(expr)

        elif kind in self.bops:
            l, r = self.run_expr(expr.get('op1')), self.run_expr(expr.get('op2'))
            tl, tr = type(l), type(r)

            if kind == '==': 
                if (tl == bool and tr == int) or (tl == int and tr == bool):
                    l = self.coerce_to_bool(l) if tl == int else l
                    r = self.coerce_to_bool(r) if tr == int else r
                elif (tl in self.structs and tl == tr):
                    return l is r
                return tl == tr and l == r
            if kind == '!=': 
                if (tl == bool and tr == int) or (tl == int and tr == bool):
                    l = self.coerce_to_bool(l) if tl == int else l
                    r = self.coerce_to_bool(r) if tr == int else r
                elif (tl in self.structs and tl == tr):
                    return l is not r
                return not (tl == tr and l == r)

            if tl == str and tr == str:
                if kind == '+': return l + r

            if tl == int and tr == int:
                if kind == '+': return l + r
                if kind == '-': return l - r
                if kind == '*': return l * r
                if kind == '/': return l // r
                if kind == '<': return l < r
                if kind == '<=': return l <= r
                if kind == '>': return l > r
                if kind == '>=': return l >= r
            
            if kind in {'&&', '||'}:
                if tl == bool and tr == bool:
                    return l and r if kind == '&&' else l or r
                if (tl == bool and tr == int) or (tl == int and tr == bool):
                    l = self.coerce_to_bool(l) if tl == int else l
                    r = self.coerce_to_bool(r) if tr == int else r
                    return l and r if kind == '&&' else l or r

            super().error(ErrorType.TYPE_ERROR, '')

        elif kind == 'neg':
            o = self.run_expr(expr.get('op1'))
            if type(o) == int: return -o
            
            super().error(ErrorType.TYPE_ERROR, '')

        elif kind == '!':
            o = self.run_expr(expr.get('op1'))
            if type(o) == bool: return not o

            super().error(ErrorType.TYPE_ERROR, '')
        
        elif kind == 'new':
            struct_name = expr.get('var_type')
            if struct_name not in self.structs:
                super().error(ErrorType.TYPE_ERROR, '')
            return {field: self.default_value(self.structs[struct_name][field]) for field in self.structs[struct_name]}
            
        return None
    
    def type_compatible(self, var_type, value):
        # Handle int to bool coercion
        if var_type == 'bool' and isinstance(value, int):
            return True
        # Check direct type compatibility
        if var_type == 'bool' and isinstance(value, bool):
            return True
        if var_type == 'int' and isinstance(value, int) and not isinstance(value, bool):
            return True
        if var_type == 'string' and isinstance(value, str):
            return True
        # Add checks for structs or other types
        if var_type in self.structs:
            if value is None:
                return True
            if isinstance(value, dict) and all(field in self.structs[var_type] for field in value):
                return True
        return False
    
    def default_value(self, var_type):
        if var_type == 'int':
            return 0
        elif var_type == 'bool':
            return False
        elif var_type == 'string':
            return ""
        else:
            return None
        
    def coerce_to_bool(self, value):
        if isinstance(value, int):
            return value != 0  # 0 -> False, non-zero -> True
        if isinstance(value, bool):
            return value
        super().error(ErrorType.TYPE_ERROR, "Invalid coercion to bool")
        
def main():
    interpreter = Interpreter()

    program = """
    func main() : void {
    print(foo(2));
    }

    func foo(x: int): void {
    print(x);
    }
    """
    interpreter.run(program)

if __name__ == '__main__':
    main()